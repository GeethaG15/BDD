require 'rubygems'
require 'Watir-Webdriver'
require 'selenium-webdriver'
$browser = Watir::Browser.new :firefox
$browser.window.maximize
$browser.goto"https://www.gillette.co.in"
$loginTab = $browser.element(xpath: "//a[@class='responsiveAccountHeader_openAccountButton']")
$RegisterTab = $browser.element(xpath: "//a[@class='responsiveAccountHeader_accountRegister']")
$forgotpassword = $browser.element(xpath: "//button[@class='forgottenPasswordModal_trigger']")
$forgotpwemail = $browser.element(xpath: "//input[@id='forgotten-password-email-field']")
$el1 =$browser.element(:xpath=>"//a[@class='responsiveAccountHeader_openAccountButton']")