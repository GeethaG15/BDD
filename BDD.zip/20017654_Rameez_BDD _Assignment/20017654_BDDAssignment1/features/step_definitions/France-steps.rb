# frozen_string_literal: true

Given(/^Navigate to first page$/) do
  $browser.goto 'https://www.gillette.co.in'
end
Then(/^I select the country France$/) do
  $browser.element(xpath: "//a[@class='language']").click
  $browser.element(xpath: "//span[contains(text(),'France')]").click
  $browser.driver.switch_to.window($browser.driver.window_handles[1])
  $browser.element(xpath: "//button[@class='optanon-allow-all accept-cookies-button']").click
  #$el2 =$browser.element(xpath: "//a[@class='responsiveAccountHeader_openAccountButton']")
  #$el2.click!
end
And(/^I click on Register$/) do
  $browser.element(xpath: "//a[@class='event_profile_login']").click
end

When(/^I provide my credentials name "([^"]*)",emailid "([^"]*)",password "([^"]*)" and referral code "([^"]*)"$/) do |arg1, arg2, arg3, arg4|
  $browser.element(xpath: "//input[@id='email_create']").send_keys(arg2)
  $browser.element(xpath: "//button[@id='SubmitCreate']").click
  $browser.element(xpath: "//input[@id='customer_firstname']").send_keys(arg1)
  $browser.element(xpath: "//input[@id='customer_lastname']").send_keys('M')
  $browser.element(xpath: "//input[@id='email']").send_keys(arg2)
  # $browser.element(xpath: "//input[@id='email_create']").send_keys(_arg2)
  $browser.element(xpath: "//input[@id='passwd']").send_keys(arg3)
  $browser.scroll.to :center
  $browser.element(xpath: "//select[@id='years']").click
  $browser.select_list(:id,'years').select_value('2001')
  $browser.element(xpath: "//select[@id='months']").click
  $browser.select_list(:id,'months').select_value('2')
  $browser.element(xpath: "//select[@id='days']").click
  $browser.select_list(:id,'days').select_value('5')
  $browser.scroll.to [0, 200]
  $browser.element(xpath: "//div[@id='uniform-noThanks']").click
  $browser.checkbox(xpath: "//span[@id='recaptcha-anchor']").click
end

Then(/^I click continue$/) do
  $browser.element(xpath: "//button[@id='submitAccount']").click
end


