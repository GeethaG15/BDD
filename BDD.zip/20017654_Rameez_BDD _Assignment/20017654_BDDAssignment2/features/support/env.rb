require 'rubygems'
require 'Watir-Webdriver'
require 'selenium-webdriver'
$browser = Watir::Browser.new :firefox
$browser.window.maximize

